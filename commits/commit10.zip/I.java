public class I extends G {

    private long k = 1234;

    private long a = 1234;

    public byte oo() {
        return 4;
    }

    public Object rr() {
        return null;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int cc() {
        return 42;
    }

    public Object pp() {
        return this;
    }
}
