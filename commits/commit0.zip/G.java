public class G {

    private double d = 100.500;

    private byte e = 1;

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
