public class D extends null {

    Object gg();

    String nn();
}
