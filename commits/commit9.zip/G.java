public class G extends null {

    private double d = 100.500;

    private byte e = 1;

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public void bb() {
        System.out.println(42);
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }
}
