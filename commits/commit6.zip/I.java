public class I extends G {

    private long k = 1234;

    private long a = 1234;

    public byte oo() {
        return 4;
    }

    public Object rr() {
        return null;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public int cc() {
        return 42;
    }
}
