public class F extends I {

    private String e = "hello";

    private long k = 4321;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public Object pp() {
        return this;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public String kk() {
        return "Yes";
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int af() {
        return -1;
    }

    public double ad() {
        return 9.11;
    }

    public long ac() {
        return 222;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int cc() {
        return 42;
    }
}
