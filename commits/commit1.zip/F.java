public class F extends I {

    private String e = "hello";

    private long k = 4321;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public String kk() {
        return "Yes";
    }
}
