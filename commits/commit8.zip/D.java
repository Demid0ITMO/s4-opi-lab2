public interface D {

    Object gg();

    String nn();
}
