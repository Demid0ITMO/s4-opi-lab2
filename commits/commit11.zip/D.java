public class D extends null {

    Object gg();

    String nn();

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void ab() {
        System.out.println("\n");
    }
}
